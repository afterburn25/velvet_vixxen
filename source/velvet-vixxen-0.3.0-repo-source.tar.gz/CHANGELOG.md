# Changelog

## 0.3.0 — Media Center

### Added

- Public Music, Photos, Gallery, Videos, and Video Watch routes
- Persistent site-wide audio player with queue, drag reorder, seek, volume, shuffle, repeat, previous/next, saved state, and Media Session metadata
- Album, track, and audio-playlist administration
- Gallery bulk upload, custom covers, drag ordering, free-preview count, scheduling, access mode, and PPV/rental pricing metadata
- Full-screen image viewer with captions, keyboard controls, zoom, and mobile swipe
- Video poster, trailer, full-media, caption, scheduling, access, and pricing administration
- Video Continue Watching foundation
- Signed expiring media delivery with path validation and Range-request support
- Media Center service/store layer for file and MySQL modes
- Audio/video playlist migration and video-caption metadata migration
- Five people-free sample galleries, three original synthetic demo songs, and a people-free demo video
- PHP 8.2/8.3 source CI, MySQL 8 migration/rollback CI, and Chromium browser-acceptance CI
- GitHub repository continuity, testing, decision, security, issue, and PR documentation

### Changed

- Homepage now displays real published galleries, tracks, and videos
- Header links now open real Music, Photos, and Videos sections
- Public media pages use the approved Velvet Vixxen visual system
- Dedicated video pages suppress the persistent audio bar so it cannot cover video controls
- Audio pauses when video playback begins, and video pauses when music playback begins
- Default demonstration content now contains five gallery cards for realistic homepage and Photos layouts

### Security

- Private media uses signed, expiring URLs rather than direct public paths
- Media endpoint rejects expired or invalid signatures and paths outside configured storage roots
- Upload types are separated by image, audio, video, and caption allowlists
- Repository safety test scans for common committed-secret patterns and forbidden `0777` files

### Tests

- Added Media Center access, store, feature, protected-media, structure, and browser acceptance tests
- Browser tests exercise public desktop/mobile routes, audio queue, lightbox, video page, owner authentication, and real track/gallery/video saves
- Migration manifest now validates six migrations and 34 declared tables

## 0.2.2 — One-Page Browser Installer

- Replaced the multi-screen wizard with one responsive installer page
- Added inline readiness, database, owner/site, optional email, review, live progress, and completion sections
- Preserved no install key, exact 12-character password minimum, safe permissions, migrations, rollback, lock, and installer cleanup

## 0.2.1 — Installer & Structure Hardening

- Added branded browser installer foundation, real server/filesystem diagnostics, organized protected folders, migration registry, and cleanup/recovery behavior

## 0.2.0 — Homepage, Visual Composer & Canva Templates

- Added approved responsive pink homepage, layered Hero/Footer composer, media library, Canva starter templates/import workflow, owner login, age gate, and audit foundation
