# Contributing

Development is organized around versioned milestones in `docs/ROADMAP.md`.

## Branching

- `main`: authoritative, tested release state
- `feature/<version>-<topic>`: active feature work
- `fix/<version>-<topic>`: targeted corrections
- `docs/<topic>`: documentation-only updates

## Required checks

Before opening or merging a pull request:

```bash
bash scripts/test.sh
```

When MySQL is available, also run:

```bash
VELVET_TEST_DB_HOST=127.0.0.1 \
VELVET_TEST_DB_PORT=3306 \
VELVET_TEST_DB_NAME=velvet_vixxen_test \
VELVET_TEST_DB_USER=root \
VELVET_TEST_DB_PASSWORD=secret \
php tests/Database/migrations_mysql.php
```

## Commit requirements

- Keep commits focused.
- Include tests for behavior changes.
- Update status and handoff documents when milestone state changes.
- Never commit production secrets or private media.
