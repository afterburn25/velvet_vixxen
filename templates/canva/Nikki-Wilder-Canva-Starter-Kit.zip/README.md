# Canva source templates

These lightweight SVG templates are intentionally kept in source control. The release build may also include generated PPTX files and a richer starter-kit ZIP. Import an SVG into Canva, replace the dashed model-photo area, export the artwork, and import it through Admin → Canva Templates.
